// Reusable Card Component - QUESTION 3: Functional Component
const Card = ({ title, description, level }) => {
  return (
    <div className="card">
      <h2>{title}</h2>
      <p>{description}</p>
      <span className="badge">Level: {level}</span>
    </div>
  );
};

export default Card;
