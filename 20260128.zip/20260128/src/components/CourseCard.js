import React from 'react';
import './CourseCard.css';

const CourseCard = ({ courseId, courseName, instructor, duration, description, level }) => {
  return (
    <div className="course-card">
      <div className="course-header">
        <h3 className="course-name">{courseName}</h3>
        <span className={`course-level ${level.toLowerCase()}`}>{level}</span>
      </div>
      
      <p className="course-instructor">
        <strong>Instructor:</strong> {instructor}
      </p>
      
      <p className="course-duration">
        <strong>Duration:</strong> {duration}
      </p>
      
      <p className="course-description">{description}</p>
      
      <div className="course-footer">
        <button className="course-btn">Learn More</button>
      </div>
    </div>
  );
};

export default CourseCard;
