import React from 'react';
import './Dashboard.css';
import WelcomeMessage from './WelcomeMessage';
import CourseCard from './CourseCard';

const Dashboard = () => {
  const courses = [
    {
      courseId: 1,
      courseName: 'React Basics',
      instructor: 'Jane Smith',
      duration: '4 weeks',
      description: 'Learn the fundamentals of React including components, hooks, and state management.',
      level: 'Beginner'
    },
    {
      courseId: 2,
      courseName: 'Advanced JavaScript',
      instructor: 'John Doe',
      duration: '6 weeks',
      description: 'Deep dive into ES6+ features, closures, prototypes, and asynchronous programming.',
      level: 'Intermediate'
    },
    {
      courseId: 3,
      courseName: 'Full-Stack Web Development',
      instructor: 'Mike Johnson',
      duration: '12 weeks',
      description: 'Master front-end and back-end development using React, Node.js, and MongoDB.',
      level: 'Advanced'
    },
    {
      courseId: 4,
      courseName: 'CSS Mastery',
      instructor: 'Sarah Williams',
      duration: '3 weeks',
      description: 'Become proficient in CSS3, Flexbox, Grid, and responsive design techniques.',
      level: 'Beginner'
    }
  ];

  return (
    <div className="dashboard">
      <WelcomeMessage
        title="Welcome to Our Learning Platform"
        subtitle="Explore a world of courses and enhance your skills"
        userName="Student"
      />

      <div className="courses-section">
        <h2 className="courses-title">Featured Courses</h2>
        <div className="courses-grid">
          {courses.map((course) => (
            <CourseCard
              key={course.courseId}
              courseId={course.courseId}
              courseName={course.courseName}
              instructor={course.instructor}
              duration={course.duration}
              description={course.description}
              level={course.level}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
