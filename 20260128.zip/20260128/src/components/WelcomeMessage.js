import React from 'react';
import './WelcomeMessage.css';

const WelcomeMessage = ({ title, subtitle, userName }) => {
  return (
    <div className="welcome-container">
      <div className="welcome-card">
        <h1 className="welcome-title">{title}</h1>
        {userName && <p className="welcome-user">Welcome, {userName}!</p>}
        <p className="welcome-subtitle">{subtitle}</p>
      </div>
    </div>
  );
};

export default WelcomeMessage;
