// Reusable Welcome Component
const Welcome = ({ userName }) => {
  return (
    <div className="header">
      <h1>Welcome to Learning Hub</h1>
      <p>Hello, {userName}! Explore our courses and expand your skills.</p>
    </div>
  );
};

export default Welcome;
