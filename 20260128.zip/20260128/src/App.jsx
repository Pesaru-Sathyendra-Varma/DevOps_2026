// Main App Component - QUESTION 4: How components are rendered
import Welcome from './Welcome';
import Card from './Card';

function App() {
  // Static course data
  const courses = [
    { id: 1, title: 'React Basics', description: 'Learn React fundamentals and build UI components', level: 'Beginner' },
    { id: 2, title: 'JavaScript Advanced', description: 'Master ES6+, async/await, and modern patterns', level: 'Intermediate' },
    { id: 3, title: 'Web Design', description: 'Create beautiful, responsive user interfaces', level: 'Beginner' },
    { id: 4, title: 'Node.js Backend', description: 'Build scalable server-side applications', level: 'Advanced' }
  ];

  return (
    <div className="container">
      {/* Question 4: Components rendered here */}
      <Welcome userName="Developer" />
      
      <div className="courses-grid">
        {/* Question 5: Benefits of reusable components - Card is reused multiple times */}
        {courses.map(course => (
          <Card 
            key={course.id} 
            title={course.title} 
            description={course.description} 
            level={course.level}
          />
        ))}
      </div>
    </div>
  );
}

export default App;
