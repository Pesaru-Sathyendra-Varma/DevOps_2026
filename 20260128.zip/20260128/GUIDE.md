# React Dashboard Project - Complete Guide

## PROJECT STRUCTURE
```
react-dashboard/
├── src/
│   ├── App.jsx          (Main component)
│   ├── Card.jsx         (Reusable card component)
│   ├── Welcome.jsx      (Welcome header component)
│   ├── index.css        (Minimal styles)
│   └── main.jsx         (Entry point)
├── index.html           (Root HTML file)
├── package.json         (Dependencies)
├── vite.config.js       (Vite configuration)
└── .gitignore
```

---

## ANSWER 1: HOW TO SET UP A NEW REACT PROJECT

### Option A: Using Vite (Recommended - Lighter, Faster)
```bash
npm create vite@latest my-app -- --template react
cd my-app
npm install
npm run dev
```

### Option B: Using Create React App
```bash
npx create-react-app my-app
cd my-app
npm start
```

### Why Vite for "less storage"?
- **Vite**: ~50MB (minimal dependencies)
- **Create React App**: ~300MB+ (includes many unused tools)
- Vite builds faster and includes only essential packages

---

## ANSWER 2: ROLE OF PACKAGE.JSON

The package.json file is the **project manifest** that:

1. **Declares Dependencies** - Lists required packages (react, react-dom)
2. **Defines Scripts** - Commands to run (`npm run dev`, `npm run build`)
3. **Manages Versions** - Specifies which versions of packages to install
4. **Project Metadata** - Name, version, author information

### Example:
```json
{
  "name": "react-dashboard",
  "version": "1.0.0",
  "scripts": {
    "dev": "vite",
    "build": "vite build"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0"
  }
}
```

---

## ANSWER 3: CREATE A FUNCTIONAL COMPONENT IN REACT

A **functional component** is a JavaScript function that returns JSX (HTML-like syntax).

### Simple Example:
```jsx
// Card.jsx - Reusable Card Component
const Card = ({ title, description, level }) => {
  return (
    <div className="card">
      <h2>{title}</h2>
      <p>{description}</p>
      <span className="badge">Level: {level}</span>
    </div>
  );
};

export default Card;
```

### Key Points:
- **Function-based** (not class-based)
- **Props** (title, description, level) allow customization
- **Returns JSX** (looks like HTML but is JavaScript)
- **Reusable** - use the same component multiple times

---

## ANSWER 4: HOW COMPONENTS ARE RENDERED IN APP

Components are rendered using **composition** inside the main App.jsx:

```jsx
// App.jsx
import Welcome from './Welcome';
import Card from './Card';

function App() {
  const courses = [
    { id: 1, title: 'React Basics', ... },
    { id: 2, title: 'JavaScript Advanced', ... }
  ];

  return (
    <div className="container">
      {/* Render Welcome component */}
      <Welcome userName="Developer" />
      
      {/* Render Card components dynamically */}
      <div className="courses-grid">
        {courses.map(course => (
          <Card 
            key={course.id}
            title={course.title}
            description={course.description}
            level={course.level}
          />
        ))}
      </div>
    </div>
  );
}

export default App;
```

### Rendering Flow:
1. **index.html** has `<div id="root">`
2. **main.jsx** mounts React to this div
3. **App.jsx** is the root component
4. **App** renders child components (Welcome, Card)

---

## ANSWER 5: BENEFITS OF REUSABLE COMPONENTS

| Benefit | Example |
|---------|---------|
| **Less Code** | Card component used 4 times, written once |
| **Easy Maintenance** | Update Card style, all cards update automatically |
| **Consistency** | All cards look and work the same |
| **Scalability** | Add 100 courses? Just pass new data, no code changes |
| **Reusability** | Use Card in different pages/projects |
| **Testing** | Test Card once, works everywhere |

In this project: The `Card` component is used 4 times with different data, but the code is written only once!

---

## HOW TO RUN THE PROJECT

```bash
# Navigate to project
cd react-dashboard

# Install dependencies
npm install

# Start development server
npm run dev

# Build for production (optimized, smaller file)
npm run build
```

Visit: `http://localhost:3000`

---

## MINIMAL FILE SIZES

- **package.json**: ~0.5 KB
- **vite.config.js**: ~0.3 KB
- **App.jsx**: ~0.8 KB
- **Card.jsx**: ~0.3 KB
- **Welcome.jsx**: ~0.2 KB
- **index.css**: ~0.9 KB
- **Total Source Code**: ~3 KB (ultra-lightweight!)

The `node_modules` folder (installed dependencies) is ~50MB but not deployed. The **build output** is only ~100-200 KB after optimization.

---

## NEXT STEPS

1. Run `npm install` to install React
2. Run `npm run dev` to start the server
3. Modify courses data in App.jsx
4. Create more components (Header, Footer, etc.)
5. Run `npm run build` for production

