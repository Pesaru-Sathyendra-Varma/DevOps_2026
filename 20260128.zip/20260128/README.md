# React Dashboard

A simple front-end dashboard built with React to display static information such as welcome messages and course details.

## Project Structure

```
react-dashboard/
├── public/
│   └── index.html
├── src/
│   ├── components/
│   │   ├── Dashboard.js
│   │   ├── Dashboard.css
│   │   ├── WelcomeMessage.js
│   │   ├── WelcomeMessage.css
│   │   ├── CourseCard.js
│   │   └── CourseCard.css
│   ├── App.js
│   ├── App.css
│   ├── index.js
│   ├── index.css
│   └── reportWebVitals.js
├── package.json
└── README.md
```

## Features

- **Reusable Components**: Modular React components for different sections
- **WelcomeMessage Component**: Displays personalized welcome messages
- **CourseCard Component**: Displays course details with instructor, duration, and level
- **Dashboard Component**: Main container that organizes all components
- **Responsive Design**: Mobile-friendly layout using CSS Grid
- **Modern Styling**: Gradient backgrounds, animations, and hover effects

## Components

### WelcomeMessage
Displays a welcome header with title, user greeting, and subtitle.

**Props:**
- `title` (string): Main title text
- `subtitle` (string): Subtitle or description
- `userName` (string): Name of the user to personalize greeting

### CourseCard
Displays individual course information in a card format.

**Props:**
- `courseId` (number): Unique course identifier
- `courseName` (string): Name of the course
- `instructor` (string): Instructor name
- `duration` (string): Course duration
- `description` (string): Course description
- `level` (string): Course level (Beginner, Intermediate, Advanced)

### Dashboard
Main component that contains the welcome message and a grid of course cards.

## Installation

1. Navigate to the project directory:
```bash
cd react-dashboard
```

2. Install dependencies:
```bash
npm install
```

## Running the Application

To start the development server:

```bash
npm start
```

The application will open in your browser at `http://localhost:3000`

## Building for Production

To create a production build:

```bash
npm run build
```

## Styling

The project uses CSS modules and custom stylesheets with:
- Gradient backgrounds
- Smooth animations and transitions
- Hover effects for interactivity
- Mobile-responsive design
- Color-coded course levels

## Technologies Used

- **React 18.2.0**: JavaScript library for building UI components
- **React DOM**: React rendering library
- **CSS3**: For styling and animations

## Future Enhancements

- Add course enrollment functionality
- Implement filtering and search features
- Add course ratings and reviews
- Connect to a backend API for dynamic course data
- Add user authentication
- Implement dark mode toggle
